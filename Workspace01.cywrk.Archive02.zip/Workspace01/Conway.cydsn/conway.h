/* ========================================
 *
 * Copyright (C) 2022 by Pieter Vandevoorde
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * ========================================
*/
#include <stdint.h>

#define CON_SPEED 60

#define CON_PIX_SIZE 4

#define CON_BORDER  8 // Border pixels to remove
#define SCORE_H    20 // Room for score window

#define CON_H (((SCREEN_W - 2 * CON_BORDER) / CON_PIX_SIZE) + 1)  // extra line left
#define CON_V (((SCREEN_H - 2 * CON_BORDER - SCORE_H ) / CON_PIX_SIZE) + 2)  // extra lines top and bottom

#define MID_X CON_H / 2
#define MID_Y CON_V / 2

void ConwayInit(void);
void ConwayDraw(void);
uint16_t ConwayCounts(void);
void ConwayNext(void);

/* [] END OF FILE */
