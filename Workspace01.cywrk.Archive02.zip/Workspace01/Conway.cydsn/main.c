/* ========================================
 * 
 * Copyright (C) 2022 by Pieter Vandevoorde
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * ========================================
*/

/* Note
  P0.2 P0.3 P0.4 P3.2 contain bypass cap and should not be used
  P15.0 and P15.1 XTAL
  P15.4 CMOD
  P2.1 LED
  P2.2 SW1

*/
#include <stdio.h>
#include "project.h"
#include "screen.h"
#include "window.h"
#include "conway.h"

extern ScreenFont Font7x13;

static uint16_t video_ram[SCREEN_W * SCREEN_H / PIX_PER_WORD] __attribute__ ((aligned(32)));
Window win;

uint8_t run_conway;

/*******************************************************************************
* Function Name: ConwayInit
********************************************************************************
*
* Summary: This function is called from the interrupt routine every time a new
*          screen frame starts. The function should be as short as possible,
*          because it runs in interrupt context. Change the count value to run
*          the simulation faster or slower.
*          Time interval is CON_SPEED / 60 seconds
*
* Parameters: none
*
* Return: none
*
*******************************************************************************/
void FrameHandler() {
    static uint8_t count = 0;

    count++;
    
    if (count >= CON_SPEED) {
        count = 0;
        run_conway = 1;
    }
}

int main(void)
{
    uint16_t con_count = 0;
    char con_cnt_buf[12];
    
    CyGlobalIntEnable; /* Enable global interrupts. */

    ScreenInit(video_ram, SCREEN_W, SCREEN_H, &FrameHandler); // Initialise screen and callback
    ScreenClear(0);
    ScreenSetColor(0x70); // Sets foreground and background color (White, Black)
    
    WindowInit(&win, 40, 40, 560, 280, &Font7x13, 1); // Initialise a text window for Splash screen
    
    WindowSetCursor(&win, 80, 100);
    win.textsize_x = win.textsize_y = 2;
    WindowWriteString(&win, "Conway\'s Game of Life");
    for (uint8_t k = 0; k < 120; k++) {
        CyDelay(100);
        WindowScroll(&win, 1);
    }
    
    ScreenDrawRect(4, 4, SCREEN_W - 8, SCREEN_H - 8, 1); // Screen Border
    
    // Text window to show number of iterations and life cells
    WindowInit(&win, 20, 8, SCREEN_W - 20, 14, &Font7x13, 1);
    win.textsize_x = win.textsize_y = 1;
    WindowSetCursor(&win, 0, 0);
    WindowWriteString(&win, "Count: ");
    WindowSetCursor(&win, 110, 0);
    WindowWriteString(&win, "Cells: ");
    
    
    ConwayInit();
    ConwayDraw();
    
    for(;;)
    {
        if (run_conway) {
            sprintf(con_cnt_buf, "%5u", con_count++);
            WindowSetCursor(&win, 50, 0);
            WindowWriteString(&win, con_cnt_buf);
            WindowSetCursor(&win, 160, 0);
            sprintf(con_cnt_buf, "%5u", ConwayCounts());
            WindowWriteString(&win, con_cnt_buf);
            ConwayNext();
            ConwayDraw();
            run_conway = 0;
        }
        
        CY_PM_WFI; // Halt and wait for interrupt (every horizontal line, that is 14.8 μs)
    }
}

/* [] END OF FILE */
