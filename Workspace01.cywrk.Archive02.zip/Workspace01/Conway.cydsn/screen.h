/* ========================================
 *
 * Copyright (C) 2022 by Pieter Vandevoorde
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * ========================================
*/
#include "project.h"

#ifndef _SCREEN_H_
#define _SCREEN_H_

/* Display 1280x720    60Hz 
    Pixel Clock         74.250 MHz
    TMDS Clock         742.50 MHz
    Pixel Time          13.5 ns ±0.5%
    Horizontal Freq.  45.000 kHz
    Line Time           22.2 μs
    Vertical Freq.    60.000 Hz
    Frame Time          16.7 ms

    Horizontal Timings
    Active Pixels       1280
    Front Porch          110
    Sync Width            40
    Back Porch           220
    Blanking Total       370
    Total Pixels        1650
    Sync Polarity        pos

    Vertical Timings
    Active Lines         720
    Front Porch            5
    Sync Width             5
    Back Porch            20
    Blanking Total        30
    Total Lines          750
    Sync Polarity        pos
    
*/

#define HOR_SCALING  2
#define VERT_SCALING 2

/* VGA definitions */
// Horizontal
#define ACT_PIXELS   ( 1280 / HOR_SCALING )
#define FRONT_PORCH_H ( 110 / HOR_SCALING )
#define SYNC_H        (  40 / HOR_SCALING )
#define BACK_PORCH_H  ( 220 / HOR_SCALING )

// Vertical
#define ACT_LINES    720
#define FRONT_PORCH_V  5
#define SYNC_V         5
#define BACK_PORCH_V  20
#define TOT_LINES ( ACT_LINES + FRONT_PORCH_V + SYNC_V + BACK_PORCH_V )

#define PIX_PER_WORD 16

#define POS     1
#define NEG     0

#define H_POL   POS
#define V_POL   POS

#define ACTIVE_BIT  0
#define H_POL_BIT   1
#define V_POL_BIT   2

#define SCREEN_W  ACT_PIXELS
#define SCREEN_H  ( ACT_LINES / VERT_SCALING )

//  Possible to do LHS assignment: varGetBit(flags,4) = y;
/*
*/

/* Defines for DMA_ShiftLoad */
#define DMA_VGA_Line_BYTES_PER_BURST 2
#define DMA_VGA_Line_REQUEST_PER_BURST 1
#define DMA_VGA_Line_SRC_BASE (CYDEV_SRAM_DATA_MBASE)
#define DMA_VGA_Line_DST_BASE (CYDEV_PERIPH_BASE)
    
typedef struct Screen {
    uint16 scn_w;           // width in pixels
    uint16 scn_h;           // height in pixels
    uint16 scn_wpl;         // words per line
    uint8  scn_bbp;         // bits per pixel
    void (*scn_fh)(void);   // Pointer to a frame handler function
    uint16_t *scn_pix;      // pointer to pixel data
    struct Window *act_win; // Pointer to active window
} Screen;

typedef struct scrn_font {
   uint8_t height;
   uint8_t width;
   unsigned char *bitmap;
} ScreenFont;

/* Low level routines */
CY_ISR_PROTO( VideoLineInterrupt );

/* Screen routines */
void ScreenInit(uint16_t *pix, uint16 w, uint16 h, void (*FrameHandler)(void) );
void ScreenClear(uint8 color);
void ScreenSetColor(uint8_t col);
void ScreenSetColor2(uint8_t fg, uint8_t bg);
void ScreenWritePixel(int16_t x, int16_t y, uint16_t color);
uint8_t ScreenReadPixel(int16_t x, int16_t y);
void ScreenScroll(int16_t num);
void ScreenDrawHorLine(int16_t x0, int16_t x1, int16_t y, uint16_t color);
void ScreenDrawVertLine(int16_t x, int16_t y0, int16_t y1, uint16_t color);
void ScreenWriteLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color);
void ScreenFillRect(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t color);
void ScreenDrawCircle(int16_t x0, int16_t y0, uint16_t r, uint16_t color);
void ScreenDrawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
void ScreenDrawChar(int16_t x, int16_t y, unsigned char c, ScreenFont *fnt, uint16_t color, uint16_t bg, uint8_t size_x, uint8_t size_y);

#endif // _SCREEN_H_

/* [] END OF FILE */
