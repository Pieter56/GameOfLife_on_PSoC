/* ========================================
 *
 * Copyright (C) 2022 by Pieter Vandevoorde
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * ========================================
*/

#include "window.h"
#include "screen.h"

extern Screen scrn;

/* Forward Declarations of local functions */
void set_cursor_state(Window *win, uint8_t val);

/*******************************************************************************
* Function Name: windowInit
********************************************************************************
*
*   Summary:   Defines a rectangular text window.
*
*   Parameters:
*      win       Pointer to a Window structure
*      x_orig    Top left corner x coordinate of window
*      y_orig    Top left corner y coordinate of window
*      width     Width in pixels
*      height    Height in pixels
*      fnt       Font to use
*      mode      0 if text window, 1 for graphics window
*
*   Return: none
*
*******************************************************************************/
void WindowInit(Window *win, uint16_t x_orig, uint16_t y_orig, uint16_t width, uint16_t height, ScreenFont *fnt, uint8_t mode) {
    // TODO: check boundaries
    win->orig_x = x_orig;
    win->orig_y = y_orig;
    win->border = 2;
    win->w_x    = width;
    win->w_y    = height;
    win->mode   = mode;
    
    /* text related */
    win->rotation = 0;
    win->cursor_y   = win->cursor_x   = 0;
    win->textsize_x = win->textsize_y = 1;
    win->fnt    = fnt;
    if (fnt) {
        win->fnt_x  = fnt->width;
        win->fnt_y  = fnt->height;
    } else {
        win->fnt_x  = 6;
        win->fnt_y  = 9;
    }
    win->textcolor = 0xFFFF;
    win->textbgcolor = 0;
    win->wrap = 1;
    
    // Draw border outside the effective window
    if (win->border) ScreenDrawRect(win->orig_x - win->border, win->orig_y - win->border,
                                    win->w_x + 2 * win->border + 1, win->w_y + 2 * win->border + 1, 1);
    
    scrn.act_win = win; // Needed to blink cursor
}

/*******************************************************************************
* Function Name: windowSetFont
********************************************************************************
*
*   Summary:   Changes the currently set font
*
*   Parameters:
*      win       Pointer to a Window structure
*      fnt       Font to use
*
*   Return: none
*
*******************************************************************************/
void WindowSetFont(Window *win, ScreenFont * fnt) {
    if (win == NULL) return;
    
    win->fnt    = fnt;
    if (fnt) {
        win->fnt_x  = fnt->width;
        win->fnt_y  = fnt->height;
    }
}

/*******************************************************************************
* Function Name: WindowSetCursor
********************************************************************************
*
*   Summary:   Positions the cursor on the coordinate given. Coordinates are
*              in pixels relative to the origin of the window. The values are
*              checked for being valid.
*
*   Parameters:
*      win       Pointer to a Window structure
*      x         Top left corner x coordinate of cursor
*      y         Top left corner y coordinate of cursor
*
*   Return: none
*
*******************************************************************************/
void WindowSetCursor(Window *win, uint16_t x, uint16_t y) {

    set_cursor_state(win, 0); // Erase cursor

    if (x < win->w_x - win->fnt_x * win->textsize_x) win->cursor_x = x;
    if (y < win->w_y - win->fnt_y * win->textsize_y - 1) win->cursor_y = y;
    
    set_cursor_state(win, 1);
    
}

/*******************************************************************************
* Function Name: WindowSetCursorRel
********************************************************************************
*
*   Summary:   Changes the cursor position relative to the current position.
*              Checks are made that the resultingcursor position is valid.
*
*   Parameters:
*      win       Pointer to a Window structure
*      dx        Horizontal cursor displacement
*      dy        Vertical cursor displacement
*
*   Return: 0 if cursor move is valid
*
*******************************************************************************/
uint8_t WindowSetCursorRel(Window *win, int16_t dx, int16_t dy) {
    uint16_t pos_x = win->cursor_x + dx;
    uint16_t pos_y = win->cursor_y + dy;
    
    // Validate positions
    if ((pos_x < 0) || pos_x > win->w_x - win->fnt_x * win->textsize_x) return 1;
    if ((pos_y < 0) || pos_y >= win->w_y - win->fnt_y * win->textsize_y) return 2;
    
    set_cursor_state(win, 0); // Erase cursor

    win->cursor_x += dx;
    win->cursor_y += dy;
    
    set_cursor_state(win, 1);
    
    return 0;
}

static uint8_t  state = 0; // Cursor 0: off, 1: on

void set_cursor_state(Window *win, uint8_t val) {
    
    if (val == 0) WindowBlinkCursor(win, 0); // Erase cursor
            
    state = val;
}

void WindowBlinkCursor(Window *win, uint8_t f) {
    if (win == NULL) return;
    
    if (win->mode != 0 || state == 0) return;
    
    for (uint16_t x = 0; x < win->fnt_x - 1; x++) {
            ScreenWritePixel(win->orig_x + win->cursor_x + x, win->orig_y + win->cursor_y + win->fnt_y - 1, f );
    }
}

void WindowSetMode(Window *win, uint8_t mode) {
    win->mode = mode;
}

/*******************************************************************************
* Function Name: WindowScroll
********************************************************************************
*
*   Summary:   Scrolls the text upwards <num> pixels if num is positive, scrolls
*              downwards when num is negative. Typically used when the cursor is
*              at the end of the last line of the text window.
*
*   Parameters:
*      win       Pointer to a Window structure
*      num       Number of horizontal lines to scroll (up or down)
*
*   Return: none
*
*******************************************************************************/
void WindowScroll(Window *win, uint16_t num) {
    uint8_t  x_rem_left  = win->orig_x & 15;
    uint8_t  x_rem_right = (win->orig_x + win->w_x) & 15;
    uint16_t xl_word = (x_rem_left) ? win->orig_x / 16 + 1 : win->orig_x / 16;
    uint16_t xr_word = (win->orig_x + win->w_x) / 16;
    uint16_t pixdata;
    uint16_t pixmask_l, pixmask_r;

    uint16_t words_x = xr_word - xl_word; // words on same line to copy with memcpy
    
    uint16_t orig = win->orig_y * scrn.scn_wpl + xl_word; // in words, not pixels

    set_cursor_state(win, 0); // Erase cursor

    pixmask_l = 0xffff >> x_rem_left;
    pixmask_r = 0xffff << (16 - x_rem_right);
    
    for (uint16 y = 0; y < win->w_y - num; y++) {
        if (x_rem_left) {
            pixdata = scrn.scn_pix[orig - 1 + (y + num) * scrn.scn_wpl] & pixmask_l;
            scrn.scn_pix[orig - 1 + y * scrn.scn_wpl] &= ~pixmask_l;
            scrn.scn_pix[orig - 1 + y * scrn.scn_wpl] |= pixdata;
        }
        memcpy(&scrn.scn_pix[orig + y * scrn.scn_wpl],
               &scrn.scn_pix[orig + (y + num) * scrn.scn_wpl], 2 * words_x);
        if (x_rem_right) {
            pixdata = scrn.scn_pix[orig + words_x + (y + num) * scrn.scn_wpl] & pixmask_r;
            scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] &= ~pixmask_r;
            scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] |= pixdata;
        }
        
    }
    
    for (uint16 y = win->w_y - num; y < win->w_y; y++) {
        if (x_rem_left) scrn.scn_pix[orig - 1 + scrn.scn_wpl * y] &= ~pixmask_l;
        memset(&scrn.scn_pix[orig + scrn.scn_wpl * y], 0, 2 * words_x); // Clear last num lines of the window
        if (x_rem_right) scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] &= ~pixmask_r;
    }
    
    set_cursor_state(win, 1);
}

void WindowShowFont(Window *win) {
    WindowSetCursor(win, 0, 0);
    for (uint8_t ch = 0; ch < 255; ch++) {
        WindowWrite(win, ch);
        if (ch % 16 == 15) {
            WindowWrite(win, '\n'); // new line
            WindowWrite(win, '\r'); // new line
        }
    }
}

/*******************************************************************************
* Function Name: WindowWrite
********************************************************************************
*
* Summary:
*    Writes a character on the screen at the current cursor position.
*    Advances the cursor and wraps on a new line is required.
*    Scrolls the window one line if the cursor is on the last line
*
* Parameters:
*    win: pointer to the window where we want to write
*    c:   character to display
*
* Return: none
*
*******************************************************************************/
void WindowWrite(Window *win, uint8_t c) {
    uint16_t new_cursor_x = win->cursor_x, new_cursor_y = win->cursor_y;
    uint8_t  adv_y = 0, print_ch = 1;


    set_cursor_state(win, 0); // Erase cursor
    
    if (c == '\n') { 
        adv_y = 1;
        print_ch = 0;
    } else if (c == '\r') {
        new_cursor_x = 0;
        print_ch = 0;
    }
    
    if (print_ch) { 
        
        ScreenDrawChar(win->orig_x + new_cursor_x, win->orig_y + new_cursor_y,
        c, win->fnt, win->textcolor, win->textbgcolor, win->textsize_x, win->textsize_y);
        
        new_cursor_x += win->textsize_x * win->fnt_x; // Advance x one char
        
        if (new_cursor_x >= win->w_x) {
            new_cursor_x = 0;
            adv_y = 1;
        }          
    }
    
    if (adv_y) {
        if (new_cursor_y + win->textsize_y * win->fnt_y < win->w_y - 3) { // need extra room for cursor
            new_cursor_y += win->textsize_y * win->fnt_y;
        }
        else 
            WindowScroll(win, win->textsize_y * win->fnt_y);
    }
    
    // Update here to avoid cursor jumping around
    win->cursor_x = new_cursor_x;
    win->cursor_y = new_cursor_y;
    
    set_cursor_state(win, 1);
    

}

/*******************************************************************************
* Function Name: WindowWriteString
********************************************************************************
*
* Summary:
*    Takes a null terminated string and writes it on the screen starting at the
*    current cursor position.
*    Advances the cursor and wraps on a new line is required.
*
* Parameters:
*    win:   Pointer to the window where we want to write
*    str:   String to display
*
* Return: none
*
*******************************************************************************/
void WindowWriteString(Window *win, char *str) {
    char ch = *str++;
    
    while (ch) {
        WindowWrite(win, ch);
        ch = *str++;
    }
}

/* [] END OF FILE */
