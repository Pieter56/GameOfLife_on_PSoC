/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#ifndef VGA_H
#define VGA_H

    #include "gfxfont.h"

/* Display 1280x720    60Hz 
    Pixel Clock         74.250 MHz
    TMDS Clock         742.50 MHz
    Pixel Time          13.5 ns ±0.5%
    Horizontal Freq.  45.000 kHz
    Line Time           22.2 μs
    Vertical Freq.    60.000 Hz
    Frame Time          16.7 ms

    Horizontal Timings
    Active Pixels       1280
    Front Porch          110
    Sync Width            40
    Back Porch           220
    Blanking Total       370
    Total Pixels        1650
    Sync Polarity        pos

    Vertical Timings
    Active Lines         720
    Front Porch            5
    Sync Width             5
    Back Porch            20
    Blanking Total        30
    Total Lines          750
    Sync Polarity        pos
    
*/

#define HOR_SCALING  2
#define VERT_SCALING 2

/* VGA definitions */
// Horizontal
#define ACT_PIXELS   ( 1280 / HOR_SCALING )
#define FRONT_PORCH_H ( 110 / HOR_SCALING )
#define SYNC_H        (  40 / HOR_SCALING )
#define BACK_PORCH_H  ( 220 / HOR_SCALING )

// Vertical
#define ACT_LINES    720
#define FRONT_PORCH_V  5
#define SYNC_V         5
#define BACK_PORCH_V  20
#define TOT_LINES ( ACT_LINES + FRONT_PORCH_V + SYNC_V + BACK_PORCH_V )

#define PIX_PER_WORD 16

#define POS     1
#define NEG     0

#define H_POL   POS
#define V_POL   POS

#define ACTIVE_BIT  0
#define H_POL_BIT   1
#define V_POL_BIT   2

#define SCREEN_W  ACT_PIXELS
#define SCREEN_H  ( ACT_LINES / VERT_SCALING )

//  Possible to do LHS assignment: varGetBit(flags,4) = y;
/*
*/

/* Defines for DMA_ShiftLoad */
#define DMA_VGA_Line_BYTES_PER_BURST 2
#define DMA_VGA_Line_REQUEST_PER_BURST 1
#define DMA_VGA_Line_SRC_BASE (CYDEV_SRAM_DATA_MBASE)
#define DMA_VGA_Line_DST_BASE (CYDEV_PERIPH_BASE)
    
typedef struct Screen {
    uint16 scn_w;           // width in pixels
    uint16 scn_h;           // height in pixels
    uint16 scn_wpl;         // words per line
    uint8  scn_bbp;         // bits per pixel
    void (*scn_fh)(void);   // Pointer to a frame handler function
    uint16_t *scn_pix;      // pointer to pixel data
    struct Window *act_win; // Pointer to active window
} Screen;

typedef struct encoding {
    uint8_t rf:   1; // (1) row first, (0) column first
    uint8_t cmsb: 1; // (1) msb is left, (0) lsb is left pixels on same row
    uint8_t rmsb: 1; // (1) msb is top pixel, (0) msb is bottom pixel
} Encoding;

typedef struct vga_font {
    uint8 w;      // width
    uint8 h;      // height
    uint8 *data;  // bitmap data
    Encoding enc;
} VGA_font;

typedef struct Window {
    /* Screen related */
    uint16_t orig_x;     // x origin in pixels relative to screen
    uint16_t orig_y;     // y origin in pixels relative to screen
    uint16_t w_x;        // x width in pixels
    uint16_t w_y;        // y width in pixels
    uint8_t  border;     // border in pixels         
    uint8_t  mode;       // text (0) or graphics (1)
    uint8_t  rotation;   // Display rotation (0 thru 3)
    /* Text related */
    uint16_t cursor_x, cursor_y; // Text cursor position in pixels relative to window
    uint8_t  fnt_x, fnt_y;       // Font bounding box
    uint16_t textcolor,     ///< 16-bit text color for print()
             textbgcolor;   ///< 16-bit background color for print()
    uint8_t textsize_x,     ///< Desired magnification in X-axis of text to print()
            textsize_y;     ///< Desired magnification in Y-axis of text to print()
    int     wrap,           ///< If set, 'wrap' text at right edge of display
           _cp437;          ///< If set, use correct CP437 charset (default is off)
    GFXfont *gfxFont;

} Window;


typedef struct Bitmap {
    uint8 w;
    uint8 h;
    uint8 *data;
} Bitmap;

/* Low level routines */
void VGA_Init(void);
CY_ISR_PROTO( VideoLineInterrupt );

/* Screen routines */
void ScreenInit(uint16_t *pix, uint16 w, uint16 h, void (*FrameHandler)(void) );
void ScreenClear(uint8 color);
uint16_t ScreenGetFrame(void);
void ScreenSetColor(uint8_t col);
void ScreenSetColor2(uint8_t fg, uint8_t bg);
void ScreenWritePixel(int16_t x, int16_t y, uint16_t color);
uint8_t ScreenReadPixel(int16_t x, int16_t y);
void ScreenScroll(int16_t num);
void ScreenDrawHorLine(int16_t x0, int16_t x1, int16_t y, uint16_t color);
void ScreenDrawVertLine(int16_t x, int16_t y0, int16_t y1, uint16_t color);
void ScreenWriteLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color);
void ScreenFillRect(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t color);
void ScreenDrawBitmap(Bitmap *bmp, int16_t x, int16_t y);
void ScreenDrawCircle(int16_t x0, int16_t y0, uint16_t r, uint16_t color);
void ScreenDrawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
void VGA_DrawChar(uint8 *font, uint8 ch, int16 x, int16 y);
void ScreenTest();

/* Window routines */
void WindowInit(Window *win, uint16_t x_orig, uint16_t y_orig, uint16_t width, uint16_t height, uint8_t mode);
void WindowSetFont(Window *win, const GFXfont *font);
void WindowSetMode(Window *win, uint8_t mode);
void WindowSetCursor(Window *win, uint16_t x, uint16_t y);
uint8_t WindowSetCursorRel(Window *win, int16_t dx, int16_t dy);
void WindowShowFont(Window *win);
void WindowWrite(Window *win, uint8_t c);
void WindowWriteString(Window *win, char *str);
void WindowScroll(Window *win, uint16_t num);

//void VGA_WinInitTxt(Window *win, uint16_t x0, uint16_t y0, uint8_t cx, uint8_t cy);

void VGA_Fonts();
void VGA_InitDMA();

void Adafruit_write(Window *win, uint8_t c);
void Adafruit_drawChar(Window *win, int16_t x, int16_t y, unsigned char c,
                            uint16_t color, uint16_t bg, uint8_t size_x,
                            uint8_t size_y);

#endif // VGA_H

/* [] END OF FILE */
