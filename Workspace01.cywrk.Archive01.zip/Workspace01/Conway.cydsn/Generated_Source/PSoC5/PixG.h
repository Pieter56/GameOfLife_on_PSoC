/*******************************************************************************
* File Name: PixG.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PixG_H) /* Pins PixG_H */
#define CY_PINS_PixG_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PixG_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 PixG__PORT == 15 && ((PixG__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    PixG_Write(uint8 value);
void    PixG_SetDriveMode(uint8 mode);
uint8   PixG_ReadDataReg(void);
uint8   PixG_Read(void);
void    PixG_SetInterruptMode(uint16 position, uint16 mode);
uint8   PixG_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the PixG_SetDriveMode() function.
     *  @{
     */
        #define PixG_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define PixG_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define PixG_DM_RES_UP          PIN_DM_RES_UP
        #define PixG_DM_RES_DWN         PIN_DM_RES_DWN
        #define PixG_DM_OD_LO           PIN_DM_OD_LO
        #define PixG_DM_OD_HI           PIN_DM_OD_HI
        #define PixG_DM_STRONG          PIN_DM_STRONG
        #define PixG_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define PixG_MASK               PixG__MASK
#define PixG_SHIFT              PixG__SHIFT
#define PixG_WIDTH              1u

/* Interrupt constants */
#if defined(PixG__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in PixG_SetInterruptMode() function.
     *  @{
     */
        #define PixG_INTR_NONE      (uint16)(0x0000u)
        #define PixG_INTR_RISING    (uint16)(0x0001u)
        #define PixG_INTR_FALLING   (uint16)(0x0002u)
        #define PixG_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define PixG_INTR_MASK      (0x01u) 
#endif /* (PixG__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PixG_PS                     (* (reg8 *) PixG__PS)
/* Data Register */
#define PixG_DR                     (* (reg8 *) PixG__DR)
/* Port Number */
#define PixG_PRT_NUM                (* (reg8 *) PixG__PRT) 
/* Connect to Analog Globals */                                                  
#define PixG_AG                     (* (reg8 *) PixG__AG)                       
/* Analog MUX bux enable */
#define PixG_AMUX                   (* (reg8 *) PixG__AMUX) 
/* Bidirectional Enable */                                                        
#define PixG_BIE                    (* (reg8 *) PixG__BIE)
/* Bit-mask for Aliased Register Access */
#define PixG_BIT_MASK               (* (reg8 *) PixG__BIT_MASK)
/* Bypass Enable */
#define PixG_BYP                    (* (reg8 *) PixG__BYP)
/* Port wide control signals */                                                   
#define PixG_CTL                    (* (reg8 *) PixG__CTL)
/* Drive Modes */
#define PixG_DM0                    (* (reg8 *) PixG__DM0) 
#define PixG_DM1                    (* (reg8 *) PixG__DM1)
#define PixG_DM2                    (* (reg8 *) PixG__DM2) 
/* Input Buffer Disable Override */
#define PixG_INP_DIS                (* (reg8 *) PixG__INP_DIS)
/* LCD Common or Segment Drive */
#define PixG_LCD_COM_SEG            (* (reg8 *) PixG__LCD_COM_SEG)
/* Enable Segment LCD */
#define PixG_LCD_EN                 (* (reg8 *) PixG__LCD_EN)
/* Slew Rate Control */
#define PixG_SLW                    (* (reg8 *) PixG__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PixG_PRTDSI__CAPS_SEL       (* (reg8 *) PixG__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PixG_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PixG__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PixG_PRTDSI__OE_SEL0        (* (reg8 *) PixG__PRTDSI__OE_SEL0) 
#define PixG_PRTDSI__OE_SEL1        (* (reg8 *) PixG__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PixG_PRTDSI__OUT_SEL0       (* (reg8 *) PixG__PRTDSI__OUT_SEL0) 
#define PixG_PRTDSI__OUT_SEL1       (* (reg8 *) PixG__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PixG_PRTDSI__SYNC_OUT       (* (reg8 *) PixG__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(PixG__SIO_CFG)
    #define PixG_SIO_HYST_EN        (* (reg8 *) PixG__SIO_HYST_EN)
    #define PixG_SIO_REG_HIFREQ     (* (reg8 *) PixG__SIO_REG_HIFREQ)
    #define PixG_SIO_CFG            (* (reg8 *) PixG__SIO_CFG)
    #define PixG_SIO_DIFF           (* (reg8 *) PixG__SIO_DIFF)
#endif /* (PixG__SIO_CFG) */

/* Interrupt Registers */
#if defined(PixG__INTSTAT)
    #define PixG_INTSTAT            (* (reg8 *) PixG__INTSTAT)
    #define PixG_SNAP               (* (reg8 *) PixG__SNAP)
    
	#define PixG_0_INTTYPE_REG 		(* (reg8 *) PixG__0__INTTYPE)
#endif /* (PixG__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_PixG_H */


/* [] END OF FILE */
