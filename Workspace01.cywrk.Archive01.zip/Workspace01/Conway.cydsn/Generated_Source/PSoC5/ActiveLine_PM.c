/*******************************************************************************
* File Name: ActiveLine_PM.c
* Version 1.80
*
* Description:
*  This file contains the setup, control, and status commands to support 
*  the component operation in the low power mode. 
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "ActiveLine.h"

/* Check for removal by optimization */
#if !defined(ActiveLine_Sync_ctrl_reg__REMOVED)

static ActiveLine_BACKUP_STRUCT  ActiveLine_backup = {0u};

    
/*******************************************************************************
* Function Name: ActiveLine_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void ActiveLine_SaveConfig(void) 
{
    ActiveLine_backup.controlState = ActiveLine_Control;
}


/*******************************************************************************
* Function Name: ActiveLine_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*
*******************************************************************************/
void ActiveLine_RestoreConfig(void) 
{
     ActiveLine_Control = ActiveLine_backup.controlState;
}


/*******************************************************************************
* Function Name: ActiveLine_Sleep
********************************************************************************
*
* Summary:
*  Prepares the component for entering the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void ActiveLine_Sleep(void) 
{
    ActiveLine_SaveConfig();
}


/*******************************************************************************
* Function Name: ActiveLine_Wakeup
********************************************************************************
*
* Summary:
*  Restores the component after waking up from the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void ActiveLine_Wakeup(void)  
{
    ActiveLine_RestoreConfig();
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
