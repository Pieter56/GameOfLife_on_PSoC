/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* Note
  P0.2 P0.3 P0.4 P3.2 contain bypass cap and should not be used
  P15.0 and P15.1 XTAL
  P15.4 CMOD
  P2.1 LED
  P2.2 SW1

*/
#include <stdio.h>
#include "project.h"
#include "vga.h"
#include "conway.h"

static uint16_t video_ram[SCREEN_W * SCREEN_H / PIX_PER_WORD] __attribute__ ((aligned(32)));
Window win;

uint8_t run_conway;

/*******************************************************************************
* Function Name: ConwayInit
********************************************************************************
*
* Summary: This function is called from the interrupt routine every time a new
*          screen frame starts. The function should be as short as possible,
*          because it runs in interrupt context. Change the count value to run
*          the simulation faster or slower.
*
* Parameters: none
*
* Return: none
*
*******************************************************************************/
void FrameHandler() {
    static uint8_t count = 0;

    count++;
    
    if (count >= 40) {
        count = 0;
        run_conway = 1;
    }
}

int main(void)
{
    uint16_t con_count = 0;
    char con_cnt_buf[12];
    
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    VGA_Init();

    ScreenInit(video_ram, SCREEN_W, SCREEN_H, &FrameHandler); // Initialise screen and callback
    ScreenClear(0);
    ScreenSetColor(0x70); // Sets foreground and background color (White, Black)
    WindowInit(&win, 40, 40, 560, 240, 1); // Initialise a text window
    WindowSetCursor(&win, 80, 100);
    win.textsize_x = win.textsize_y = 2;
    WindowWriteString(&win, "Conway\'s Game of Life");
    for (uint8_t k = 0; k < 120; k++) {
        CyDelay(100);
        WindowScroll(&win, 1);
    }
    
    ScreenDrawRect(4, 4, SCREEN_W - 8, SCREEN_H - 8, 1);
    
    // Text window to show number of iterations and life cells
    WindowInit(&win, 20, 8, 600, 9, 1);
    win.textsize_x = win.textsize_y = 1;
    WindowSetCursor(&win, 0, 0);
    WindowWriteString(&win, "Count: ");
    WindowSetCursor(&win, 100, 0);
    WindowWriteString(&win, "Cells: ");
    
    
    ConwayInit();
    ConwayDraw();
    
    for(;;)
    {
        if (run_conway) {
            sprintf(con_cnt_buf, "%5u", con_count++);
            WindowSetCursor(&win, 50, 0);
            WindowWriteString(&win, con_cnt_buf);
            WindowSetCursor(&win, 150, 0);
            sprintf(con_cnt_buf, "%5u", ConwayCounts());
            WindowWriteString(&win, con_cnt_buf);
            ConwayNext();
            ConwayDraw();
            run_conway = 0;
        }
        
        CY_PM_WFI; // Halt and wait for interrupt (every horizontal line, that is 14.8 μs)
    }
}

/* [] END OF FILE */
