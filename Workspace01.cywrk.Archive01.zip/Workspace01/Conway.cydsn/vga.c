/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "vga.h"
#include "gfxfont.h"
//#include "FreeMono12pt7b.h"
//#include "FreeSans9pt7b.h"
#include "stdlib.h"
#include "glcdfont.c"

#ifndef _swap_int16_t
#define _swap_int16_t(a, b)                                                    \
  {                                                                            \
    int16_t t = a;                                                             \
    a = b;                                                                     \
    b = t;                                                                     \
  }
#endif

#ifndef pgm_read_byte
#define pgm_read_byte(addr) (*(const unsigned char *)(addr))
#endif
#ifndef pgm_read_word
#define pgm_read_word(addr) (*(const unsigned short *)(addr))
#endif
#ifndef pgm_read_dword
#define pgm_read_dword(addr) (*(const unsigned long *)(addr))
#endif

inline GFXglyph *pgm_read_glyph_ptr(const GFXfont *gfxFont, uint8_t c) {
#ifdef __AVR__
  return &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c]);
#else
  // expression in __AVR__ section may generate "dereferencing type-punned
  // pointer will break strict-aliasing rules" warning In fact, on other
  // platforms (such as STM32) there is no need to do this pointer magic as
  // program memory may be read in a usual way So expression may be simplified
  return gfxFont->glyph + c;
#endif //__AVR__
}

inline uint8_t *pgm_read_bitmap_ptr(const GFXfont *gfxFont) {
#ifdef __AVR__
  return (uint8_t *)pgm_read_pointer(&gfxFont->bitmap);
#else
  // expression in __AVR__ section generates "dereferencing type-punned pointer
  // will break strict-aliasing rules" warning In fact, on other platforms (such
  // as STM32) there is no need to do this pointer magic as program memory may
  // be read in a usual way So expression may be simplified
  return gfxFont->bitmap;
#endif //__AVR__
}

// Global variables used in this module
static Screen scrn;
static uint16_t cur_line;     // current video line out of TOT_LINES (0-749), includes blanking area
static uint16_t disp_line;    // active video line out of ACT_LINES (0-719)
static uint16_t frame_count;  // currently used to blink the cursor, can be used as an accurate timer

uint8 DMA_VGA_Line_TD[1];

/* Forward Declarations of local functions */
void blink_cursor(Window *, uint8_t);
void set_cursor_state(Window *win, uint8_t val);

/*******************************************************************************
* Function Name: VGA_Init
********************************************************************************
*
* Summary: Initialises DMA block and assigns the interrupt routine to be
*          called each time a video line is to be displayed.
*
********************************************************************************/
void VGA_Init() {
    VGA_InitDMA();
    VGA_Line_ISR_StartEx(VideoLineInterrupt);
}

/*******************************************************************************
* Function Name: VGA_InitDMA
********************************************************************************
*
* Summary:
*  Initialises the DMA that copies words of pixels from memory to the UDB
*  block that writes pixels to the screen.
*  The DMA copies one video line from memory to the screen,
*  after every 2 lines the starting address has to be adjusted to point to the
*  next video line. This is taken care of by an interrupt routine.
*
********************************************************************************/
void VGA_InitDMA() {

/* Variable declarations for DMAshift */
    uint8 DMAshift_Chan;

/* DMA Configuration for DMA_ShiftLoad */
    DMAshift_Chan = DMAshift_DmaInitialize(DMA_VGA_Line_BYTES_PER_BURST, DMA_VGA_Line_REQUEST_PER_BURST, 
        HI16(DMA_VGA_Line_SRC_BASE), HI16(DMA_VGA_Line_DST_BASE));
    DMA_VGA_Line_TD[0] = CyDmaTdAllocate();
    CyDmaTdSetConfiguration(DMA_VGA_Line_TD[0], ACT_PIXELS / 8, DMA_VGA_Line_TD[0], CY_DMA_TD_INC_SRC_ADR | DMAshift__TD_TERMOUT_EN);
    CyDmaTdSetAddress(DMA_VGA_Line_TD[0], LO16((uint32)&scrn.scn_pix), LO16((uint32)VGAgen_dp_shift_F0_PTR));
    CyDmaChSetInitialTd(DMAshift_Chan, DMA_VGA_Line_TD[0]);
    CyDmaChEnable(DMAshift_Chan, 1); // Do not destroy TD !
}

/*******************************************************************************
* Function Name: VideoFrame
********************************************************************************
*
* Summary: this routine is called from the VideoLine interrupt every time
*          a new frame starts. This takes care of the blinking of the cursor
*          and calls a user defined function to trigger other activity.
*          This routine should be as short a possible, because it is run
*          from within interrupt context.
*
* Return: none
*
********************************************************************************/
void VideoFrame() {
    static uint8_t toggle = 0;
    
    frame_count++;
    if (frame_count % 40 == 0) 
    {
        toggle = ~toggle;
        blink_cursor(scrn.act_win, toggle);
    }

    if (scrn.scn_fh != NULL) scrn.scn_fh();
}

/*******************************************************************************
* Function Name: VideoLineInterrupt
********************************************************************************
*
* Summary: This is the interrupt routine that is called at the start of a new
*          horizontal video line. It is called every 14.8 μs. Horizontal sync
*          pulses are generated by the UDB hardware block, but vertical sync
*          pulses are handled by this routine. A new hardware address has to
*          be assigned to the DMA block. However we will duplicate each horizontal
*          line, so the address changes only once every 2 vertical lines.
*          This can be changed with the parameter VERT_SCALING.
*
* Return: none
*
********************************************************************************/
// Called from DMA interrupt handler: LoadLine
// Runs every 14.8 μs
CY_ISR( VideoLineInterrupt ) {
    uint8 control = H_POL ? 0 : (1<<H_POL_BIT);
    uint8 vsync = 0;
       
    cur_line++;
    if ( cur_line >= TOT_LINES) { // Start Back Porch, new frame
        cur_line = 0;
        VideoFrame();
    } else
    if ( cur_line >= (TOT_LINES - SYNC_V) ) { // Vert Synch
        vsync = 1;
    } else
    if ( (cur_line >= BACK_PORCH_V) && (cur_line < ACT_LINES + BACK_PORCH_V ) ) { // Active line
        disp_line = cur_line - BACK_PORCH_V;
        if ( (disp_line % VERT_SCALING) == 0) {
            CyDmaTdSetAddress(DMA_VGA_Line_TD[0], LO16((uint32)&scrn.scn_pix[disp_line * scrn.scn_wpl / VERT_SCALING ]), 
                LO16((uint32)VGAgen_dp_shift_F0_PTR));
        }
        control |= 1<<ACTIVE_BIT;
    }
    control |= vsync ? (V_POL ? (1<<V_POL_BIT) : 0)      : (V_POL ? 0 : (1<<V_POL_BIT));
    control &= vsync ? (V_POL ? 0xff : ~(1<<V_POL_BIT) ) : (V_POL ? ~(1<<V_POL_BIT) : 0xff);
    ActiveLine_Write(control);
}


void startWrite() { ; }
void endWrite() { ; }


/*******************************************************************************
* Function Name: ScreenInit
********************************************************************************
*
* Summary:
*  Initialises the VGA screen.
*
* Parameters:
*  pix: pointer an array of words containing the pixels: each pixel is one bit.
*  w:   width of the screen in pixels
*  h:   height of the screen in pixels
*  FrameHandler: pointer to a function that is called at each frame change,
*                that is 60 times per second.
*
* Return: none
*
*******************************************************************************/
void ScreenInit(uint16_t *pix, uint16_t w, uint16_t h, void (*FrameHandler)() ) {
    scrn.scn_w = w;
    scrn.scn_h = h;
    scrn.scn_wpl = (w % 16) ? 1 + w / 16 : w / 16;
    scrn.scn_bbp = 1;
    scrn.scn_pix = pix;
    scrn.scn_fh  = FrameHandler;
}

/*******************************************************************************
* Function Name: ScreenClear
********************************************************************************
*
* Summary: Erases the screen, using foreground or background color
*
* Parameters:
*  color: currently 0 or 1. (0 is background color, 1 foreground)
*
* Return: none
*
*******************************************************************************/
void ScreenClear(uint8 color) {
    int val = 0;
    if (color > 0) val = 0xffff;
    memset(scrn.scn_pix, val, scrn.scn_wpl * scrn.scn_h);
}

/*******************************************************************************
* Function Name: ScreenSetColor2
********************************************************************************
*
* Summary: Sets foreground and background color. Because of limited ram memory
*          pixel size is only one bit. However, 3 pins are used to connect to
*          each of the vga colors (RGB). Therefore it is possible to choose
*          between 6 colors, plus black and white.
*
* Parameters:
*  fg: foreground color, when pixel is 1. (0x04 is red, 0x02 is green, 0x01 is blue)
*  bg: background color, when pixel is 0.
*
* Return: none
*
*******************************************************************************/
void ScreenSetColor2(uint8_t fg, uint8_t bg) {
    
    RGB_fg_Write(fg);
    RGB_bg_Write(bg);
}

/*******************************************************************************
* Function Name: ScreenSetColor
********************************************************************************
*
* Summary: Same as ScreenSetColor2, but foreground and background are packed
*          into a single color value.
*
* Parameters:
*  col: bit 6-4 defines the foreground color. bit 2-0 define the background color.
*
* Return: none
*
*******************************************************************************/
void ScreenSetColor(uint8_t col) {
    RGB_fg_Write(col >> 4);
    RGB_bg_Write(col & 0x07);
}

/*******************************************************************************
* Function Name: ScreenWritePixel
********************************************************************************
*
* Summary: Sets or clears a single pixel.
*
* Parameters:
*  x: horizontal position, 0 is left
*  y: vertical position, 0 is top of the screen
*
* Return: none
*
*******************************************************************************/
void ScreenWritePixel(int16_t x, int16_t y, uint16_t color) {
    if ((x < 0) || (y < 0) || (x >= scrn.scn_w) || (y >= scrn.scn_h)) return;
    
    uint16_t pixdata = 0x8000;
    
    pixdata >>= (x % PIX_PER_WORD);
    
    if (color > 0)
        scrn.scn_pix[x / 16 + y * scrn.scn_wpl] |= pixdata;
    else 
        scrn.scn_pix[x / 16 + y * scrn.scn_wpl] &= ~pixdata;
}

/*******************************************************************************
* Function Name: ScreenReadPixel
********************************************************************************
*
* Summary: reads the value of a single pixel.
*
* Parameters:
*  x: horizontal position, 0 is left
*  y: vertical position, 0 is top of the screen
*
* Return: 1 if set, 0 if not set
*
*******************************************************************************/
uint8_t ScreenReadPixel(int16_t x, int16_t y) {
    uint16_t pixdata = 0x8000 >> (x % PIX_PER_WORD);
    
    return (scrn.scn_pix[x / 16 + y * scrn.scn_wpl] & pixdata) ? 1 : 0 ;
}

/*******************************************************************************
* Function Name: ScreenScroll
********************************************************************************
*
* Summary: Scrolls the whole screen up or down. The last line(s) are erased.
*
* Parameters:
*  num: lines to scroll, positive is up, negative is down.
*
* Return: none
*
*******************************************************************************/
void ScreenScroll(int16_t num) {
    if (num > 0) {
        for (uint16 k = num; k < SCREEN_H; k++)
            memcpy(&scrn.scn_pix[(k - num) * scrn.scn_wpl], &scrn.scn_pix[k * scrn.scn_wpl], scrn.scn_wpl);
        memset(&scrn.scn_pix[scrn.scn_wpl * (SCREEN_H - num)], 0, num * scrn.scn_wpl);
    }
    if (num < 0) {
        for (uint16 k = SCREEN_H - num; k >= 0; k--)
            memcpy(&scrn.scn_pix[(k + num) * scrn.scn_wpl], &scrn.scn_pix[k * scrn.scn_wpl], scrn.scn_wpl);
        memset(&scrn.scn_pix[scrn.scn_wpl * SCREEN_H], 0, num * scrn.scn_wpl);
    }
}

/*******************************************************************************
* Function Name: ScreenDrawHorLine
********************************************************************************
*
* Summary: Draw a horizontal line
*
* Parameters:
*  x: horizontal starting position
*  y: vertical starting position
*  w: length
*  col: if col > 0, foreground else background
*
* Return: none
*
*******************************************************************************/
void ScreenDrawHorLine(int16_t x, int16_t y, int16_t w, uint16_t color) {
    if (y >= scrn.scn_h || y < 0) return;
    if (x + w >= scrn.scn_w) w = scrn.scn_w - x;
    for (uint16 p = x; p < x + w; p++) ScreenWritePixel(p, y, color); 
}

/*******************************************************************************
* Function Name: ScreenDrawVertLine
********************************************************************************
*
* Summary: Draw a vertical line
*
* Parameters:
*  x: horizontal starting position
*  y: vertical starting position
*  h: vertical length
*  col: if col > 0, foreground else background
*
* Return: none
*
*******************************************************************************/
void ScreenDrawVertLine(int16_t x, int16_t y, int16_t h, uint16_t color) {
    if (x < 0 || x >= scrn.scn_w) return;
    if (y + h >= scrn.scn_h) h = scrn.scn_h - y;
    for (uint16 p = y; p < y + h; p++) ScreenWritePixel(x, p, color); 
}

/*******************************************************************************
* Function Name: ScreenWriteLine
********************************************************************************
*
* Summary: Draw a line between 2 points using Bresenham's algorithm
*
* Parameters:
*    x0  Start point x coordinate
*    y0  Start point y coordinate
*    x1  End point x coordinate
*    y1  End point y coordinate
*    color: if color > 0, foreground else background
*
* Return: none
*
*******************************************************************************/
void ScreenWriteLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color) {
  int16_t steep = abs(y1 - y0) > abs(x1 - x0);
  if (steep) {
    _swap_int16_t(x0, y0);
    _swap_int16_t(x1, y1);
  }

  if (x0 > x1) {
    _swap_int16_t(x0, x1);
    _swap_int16_t(y0, y1);
  }

  int16_t dx, dy;
  dx = x1 - x0;
  dy = abs(y1 - y0);

  int16_t err = dx / 2;
  int16_t ystep;

  if (y0 < y1) {
    ystep = 1;
  } else {
    ystep = -1;
  }

  for (; x0 <= x1; x0++) {
    if (steep) {
      ScreenWritePixel(y0, x0, color);
    } else {
      ScreenWritePixel(x0, y0, color);
    }
    err -= dy;
    if (err < 0) {
      y0 += ystep;
      err += dx;
    }
  }
}

/*******************************************************************************
* Function Name: ScreenFillRect
********************************************************************************
*
* Summary: Draw a filled rectangle, given the upper left starting point and
*          the height and width of the rectangle.
*
* Parameters:
*    x   Start point x coordinate
*    y   Start point y coordinate
*    w   Horizontal width
*    h   Vertical height
*    color: if color > 0, foreground else background
*
* Return: none
*
*******************************************************************************/                            
void ScreenFillRect(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t color) {
  for (uint16_t i = x; i < x + w; i++) {
    ScreenDrawVertLine(i, y, h, color);
  }
}

/*******************************************************************************
* Function Name: ScreenDrawCircle
********************************************************************************
*
* Summary: Draw a filled rectangle, given the upper left starting point and
*          the height and width of the rectangle.
*
* Parameters:
*    x0   Center-point x coordinate
*    y0   Center-point y coordinate
*    r    Circle radius
*    color: if color > 0, foreground else background
*
* Return: none
*
*******************************************************************************/ 
void ScreenDrawCircle(int16_t x0, int16_t y0, uint16_t r, uint16_t color) {

  int16_t f = 1 - r;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * r;
  int16_t x = 0;
  int16_t y = r;

  startWrite();
  ScreenWritePixel(x0, y0 + r, color);
  ScreenWritePixel(x0, y0 - r, color);
  ScreenWritePixel(x0 + r, y0, color);
  ScreenWritePixel(x0 - r, y0, color);

  while (x < y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;

    ScreenWritePixel(x0 + x, y0 + y, color);
    ScreenWritePixel(x0 - x, y0 + y, color);
    ScreenWritePixel(x0 + x, y0 - y, color);
    ScreenWritePixel(x0 - x, y0 - y, color);
    ScreenWritePixel(x0 + y, y0 + x, color);
    ScreenWritePixel(x0 - y, y0 + x, color);
    ScreenWritePixel(x0 + y, y0 - x, color);
    ScreenWritePixel(x0 - y, y0 - x, color);
  }
  endWrite();
}

/*******************************************************************************
* Function Name: ScreenDrawRect
********************************************************************************
*   Summary:   Draw a rectangle with no fill color
*
*   Parameters:
*      x   Top left corner x coordinate
*      y   Top left corner y coordinate
*      w   Width in pixels
*      h   Height in pixels
*      color: if color > 0, foreground else background
*
* Return: none
*
*******************************************************************************/
void ScreenDrawRect(int16_t x, int16_t y, int16_t w, int16_t h,
                            uint16_t color) {
  startWrite();
  ScreenDrawHorLine(x, y, w, color);
  ScreenDrawHorLine(x, y + h - 1, w, color);
  ScreenDrawVertLine(x, y, h, color);
  ScreenDrawVertLine(x + w - 1, y, h, color);
  endWrite();
}


/* Window Routines */

/*******************************************************************************
* Function Name: windowInit
********************************************************************************
*
*   Summary:   Defines a rectangular text window.
*
*   Parameters:
*      win       Pointer to a Window structure
*      x_orig    Top left corner x coordinate of window
*      y_orig    Top left corner y coordinate of window
*      width     Width in pixels
*      height    Height in pixels
*      mode      0 if text window, 1 for graphics window
*
*   Return: none
*
*******************************************************************************/
void WindowInit(Window *win, uint16_t x_orig, uint16_t y_orig, uint16_t width, uint16_t height, uint8_t mode) {
    // TODO: check boundaries
    win->orig_x = x_orig;
    win->orig_y = y_orig;
    win->border = 2;
    win->w_x    = width;
    win->w_y    = height;
    win->mode   = mode;
    
    /* text related */
    win->rotation = 0;
    win->cursor_y   = win->cursor_x   = 0;
    win->textsize_x = win->textsize_y = 1;
    win->fnt_x    = 6;
    win->fnt_y    = 9;

    win->textcolor = 0xFFFF;
    win->textbgcolor = 0;
    win->wrap = 1;
    win->_cp437 = 0;
    win->gfxFont = NULL;
    
    // Draw border outside the effective window
    if (win->border) ScreenDrawRect(win->orig_x - win->border, win->orig_y - win->border,
                                    win->w_x + 2 * win->border + 1, win->w_y + 2 * win->border + 1, 1);
    
    scrn.act_win = win; // Needed to blink cursor
}

void WindowSetFont(Window *win, const GFXfont *font) {
    win->gfxFont = (GFXfont *)font;
}

/*******************************************************************************
* Function Name: WindowSetCursor
********************************************************************************
*
*   Summary:   Positions the cursor on the coordinate given. Coordinates are
*              in pixels relative to the origin of the window. The values are
*              checked for being valid.
*
*   Parameters:
*      win       Pointer to a Window structure
*      x         Top left corner x coordinate of cursor
*      y         Top left corner y coordinate of cursor
*
*   Return: none
*
*******************************************************************************/
void WindowSetCursor(Window *win, uint16_t x, uint16_t y) {

    set_cursor_state(win, 0); // Erase cursor

    if (x < win->w_x - win->fnt_x * win->textsize_x) win->cursor_x = x;
    if (y < win->w_y - win->fnt_y * win->textsize_y - 1) win->cursor_y = y;
    
    set_cursor_state(win, 1);
    
}

/*******************************************************************************
* Function Name: WindowSetCursorRel
********************************************************************************
*
*   Summary:   Changes the cursor position relative to the current position.
*              Checks are made that the resultingcursor position is valid.
*
*   Parameters:
*      win       Pointer to a Window structure
*      dx        Horizontal cursor displacement
*      dy        Vertical cursor displacement
*
*   Return: 0 if cursor move is valid
*
*******************************************************************************/
uint8_t WindowSetCursorRel(Window *win, int16_t dx, int16_t dy) {
    uint16_t pos_x = win->cursor_x + dx;
    uint16_t pos_y = win->cursor_y + dy;
    
    // Validate positions
    if ((pos_x < 0) || pos_x > win->w_x - win->fnt_x * win->textsize_x) return 1;
    if ((pos_y < 0) || pos_y >= win->w_y - win->fnt_y * win->textsize_y) return 2;
    
    set_cursor_state(win, 0); // Erase cursor

    win->cursor_x += dx;
    win->cursor_y += dy;
    
    set_cursor_state(win, 1);
    
    return 0;
}

static uint8_t  state = 0; // Cursor 0: off, 1: on

void set_cursor_state(Window *win, uint8_t val) {
    
    if (val == 0) blink_cursor(win, 0); // Erase cursor
            
    state = val;
}

void blink_cursor(Window *win, uint8_t f) {
    if (win == NULL) return;
    
    if (win->mode != 0 || state == 0) return;
    
    for (uint16_t x = 0; x < win->fnt_x - 1; x++) {
            ScreenWritePixel(win->orig_x + win->cursor_x + x, win->orig_y + win->cursor_y + win->fnt_y - 1, f );
    }
}

void WindowSetMode(Window *win, uint8_t mode) {
    win->mode = mode;
}

/*******************************************************************************
* Function Name: WindowScroll
********************************************************************************
*
*   Summary:   Scrolls the text upwards <num> pixels if num is positive, scrolls
*              downwards when num is negative. Typically used when the cursor is
*              at the end of the last line of the text window.
*
*   Parameters:
*      win       Pointer to a Window structure
*      num       Number of horizontal lines to scroll (up or down)
*
*   Return: none
*
*******************************************************************************/
void WindowScroll(Window *win, uint16_t num) {
    uint8_t  x_rem_left  = win->orig_x & 15;
    uint8_t  x_rem_right = (win->orig_x + win->w_x) & 15;
    uint16_t xl_word = (x_rem_left) ? win->orig_x / 16 + 1 : win->orig_x / 16;
    uint16_t xr_word = (win->orig_x + win->w_x) / 16;
    uint16_t pixdata;
    uint16_t pixmask_l, pixmask_r;

    uint16_t words_x = xr_word - xl_word; // words on same line to copy with memcpy
    
    uint16_t orig = win->orig_y * scrn.scn_wpl + xl_word; // in words, not pixels

    set_cursor_state(win, 0); // Erase cursor

    pixmask_l = 0xffff >> x_rem_left;
    pixmask_r = 0xffff << (16 - x_rem_right);
    
    for (uint16 y = 0; y < win->w_y - num; y++) {
        if (x_rem_left) {
            pixdata = scrn.scn_pix[orig - 1 + (y + num) * scrn.scn_wpl] & pixmask_l;
            scrn.scn_pix[orig - 1 + y * scrn.scn_wpl] &= ~pixmask_l;
            scrn.scn_pix[orig - 1 + y * scrn.scn_wpl] |= pixdata;
        }
        memcpy(&scrn.scn_pix[orig + y * scrn.scn_wpl],
               &scrn.scn_pix[orig + (y + num) * scrn.scn_wpl], 2 * words_x);
        if (x_rem_right) {
            pixdata = scrn.scn_pix[orig + words_x + (y + num) * scrn.scn_wpl] & pixmask_r;
            scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] &= ~pixmask_r;
            scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] |= pixdata;
        }
        
    }
    
    for (uint16 y = win->w_y - num; y < win->w_y; y++) {
        if (x_rem_left) scrn.scn_pix[orig - 1 + scrn.scn_wpl * y] &= ~pixmask_l;
        memset(&scrn.scn_pix[orig + scrn.scn_wpl * y], 0, 2 * words_x); // Clear last num lines of the window
        if (x_rem_right) scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] &= ~pixmask_r;
    }
    
    set_cursor_state(win, 1);
}

void WindowShowFont(Window *win) {
    WindowSetCursor(win, 0, 0);
    for (uint8_t ch = 0; ch < 255; ch++) {
        WindowWrite(win, ch);
        if (ch % 16 == 15) {
            WindowWrite(win, '\n'); // new line
            WindowWrite(win, '\r'); // new line
        }
    }
}

/*******************************************************************************
* Function Name: WindowWrite
********************************************************************************
*
* Summary:
*    Writes a character on the screen at the current cursor position.
*    Advances the cursor and wraps on a new line is required.
*    Scrolls the window one line if the cursor is on the last line
*
* Parameters:
*    win: pointer to the window where we want to write
*    c:   character to display
*
* Return: none
*
*******************************************************************************/
void WindowWrite(Window *win, uint8_t c) {
    uint16_t new_cursor_x = win->cursor_x, new_cursor_y = win->cursor_y;
    uint8_t  adv_y = 0, print_ch = 1;

    if (!win->gfxFont) { // 'Classic' built-in font

        set_cursor_state(win, 0); // Erase cursor
        
        if (c == '\n') { 
            adv_y = 1;
            print_ch = 0;
        } else if (c == '\r') {
            new_cursor_x = 0;
            print_ch = 0;
        }
        
        if (print_ch) {
            Adafruit_drawChar(win, win->orig_x + new_cursor_x, win->orig_y + new_cursor_y,
            c, win->textcolor, win->textbgcolor, win->textsize_x, win->textsize_y);
            
            new_cursor_x += win->textsize_x * win->fnt_x; // Advance x one char
            
            if (new_cursor_x >= win->w_x) {
                new_cursor_x = 0;
                adv_y = 1;
            }          
        }
        
        if (adv_y) {
            if (new_cursor_y + win->textsize_y * win->fnt_y < win->w_y - 3) { // need extra room for cursor
                new_cursor_y += win->textsize_y * win->fnt_y;
            }
            else 
                WindowScroll(win, win->textsize_y * win->fnt_y);
        }
        
        // Update here to avoid cursor jumping around
        win->cursor_x = new_cursor_x;
        win->cursor_y = new_cursor_y;
        
        set_cursor_state(win, 1);
        
    }
}

/*******************************************************************************
* Function Name: WindowWriteString
********************************************************************************
*
* Summary:
*    Takes a null terminated string and writes it on the screen starting at the
*    current cursor position.
*    Advances the cursor and wraps on a new line is required.
*
* Parameters:
*    win:   Pointer to the window where we want to write
*    str:   String to display
*
* Return: none
*
*******************************************************************************/
void WindowWriteString(Window *win, char *str) {
    char ch = *str++;
    
    while (ch) {
        WindowWrite(win, ch);
        ch = *str++;
    }
}

/*
void VGA_DrawBitmap(BitmapStr *bmp, int16_t x, int16_t y) {
    uint16 start_x, start_y, end_x, end_line;
    uint8 pixels, mask;
    uint8 *src_pix = bmp->data;
    uint8 *dst_ptr;
    uint8  pix_off;
    
    end_x = (x + bmp->w > cv.cv_w) ? cv.cv_w : x + bmp->w;
    end_line = (y + bmp->h > cv.cv_h) ? cv.cv_h : y + bmp->h;
    
    for (uint16 line; line < end_line; line++) {
        uint16 k = x;
        dst_ptr = (uint8 *) &cv.cv_pix[line * cv.cv_wpl * 2 + x / 8];

        while (k < end_x) {
            pix_off = k % 8;

            mask = 0xff >> pix_off;

            pixels = *src_pix++;
            pixels >>= pix_off;
    
            *dst_ptr &= ~mask;
            *dst_ptr |= pixels;

        }
    }
}
*/


                            
/**************************************************************************/
/*!
    @brief Set the font to display when print()ing, either custom or default
    @param  f  The GFXfont object, if NULL use built in 6x8 font
*/
/**************************************************************************
void VGA_setFont(const GFXfont *f) {
  if (f) {          // Font struct pointer passed in?
    if (!cv.gfxFont) { // And no current font struct?
      // Switching from classic to new font behavior.
      // Move cursor pos down 6 pixels so it's on baseline.
      cv.cursor_y += 6;
    }
  } else if (cv.gfxFont) { // NULL passed.  Current font struct defined?
    // Switching from new to classic font behavior.
    // Move cursor pos up 6 pixels so it's at top-left of char.
    cv.cursor_y -= 6;
  }
  cv.gfxFont = (GFXfont *)f;
}
*/

// Draw a character
/**************************************************************************/
/*!
   @brief   Draw a single character using screen coordinates
    @param    x   Bottom left corner x coordinate
    @param    y   Bottom left corner y coordinate
    @param    c   The 8-bit font-indexed character (likely ascii)
    @param    color 16-bit 5-6-5 Color to draw chraracter with
    @param    bg 16-bit 5-6-5 Color to fill background with (if same as color,
   no background)
    @param    size_x  Font magnification level in X-axis, 1 is 'original' size
    @param    size_y  Font magnification level in Y-axis, 1 is 'original' size
*/
/**************************************************************************/
void Adafruit_drawChar(Window *win, int16_t x, int16_t y, unsigned char c,
                            uint16_t color, uint16_t bg, uint8_t size_x,
                            uint8_t size_y) {

  if (!win->gfxFont) { // 'Classic' built-in font

    if (!win->_cp437 && (c >= 176))
      c++; // Handle 'classic' charset behavior

    startWrite();
    for (int8_t i = 0; i < 5; i++) { // Char bitmap = 5 columns
      uint8_t line = pgm_read_byte(&font[c * 5 + i]);
      for (int8_t j = 0; j < 8; j++, line >>= 1) {
        if (line & 1) {
          if (size_x == 1 && size_y == 1)
            ScreenWritePixel(x + i, y + j, color);
          else
            ScreenFillRect(x + i * size_x, y + j * size_y, size_x, size_y,
                          color);
        } else if (bg != color) {
          if (size_x == 1 && size_y == 1)
            ScreenWritePixel(x + i, y + j, bg);
          else
            ScreenFillRect(x + i * size_x, y + j * size_y, size_x, size_y, bg);
        }
      }
    }
    if (bg != color) { // If opaque, draw vertical line for last column
      if (size_x == 1 && size_y == 1)
        ScreenDrawVertLine(x + 5, y, 8, bg);
      else
        ScreenFillRect(x + 5 * size_x, y, size_x, 8 * size_y, bg);
    }
    endWrite();

  } else { // Custom font

    // Character is assumed previously filtered by write() to eliminate
    // newlines, returns, non-printable characters, etc.  Calling
    // drawChar() directly with 'bad' characters of font may cause mayhem!

    c -= (uint8_t)pgm_read_byte(&win->gfxFont->first);
    GFXglyph *glyph = pgm_read_glyph_ptr(win->gfxFont, c);
    uint8_t *bitmap = pgm_read_bitmap_ptr(win->gfxFont);

    uint16_t bo = pgm_read_word(&glyph->bitmapOffset);
    uint8_t w = pgm_read_byte(&glyph->width), h = pgm_read_byte(&glyph->height);
    int8_t xo = pgm_read_byte(&glyph->xOffset),
           yo = pgm_read_byte(&glyph->yOffset);
    uint8_t xx, yy, bits = 0, bit = 0;
    int16_t xo16 = 0, yo16 = 0;

    if (size_x > 1 || size_y > 1) {
      xo16 = xo;
      yo16 = yo;
    }

    // Todo: Add character clipping here

    // NOTE: THERE IS NO 'BACKGROUND' COLOR OPTION ON CUSTOM FONTS.
    // THIS IS ON PURPOSE AND BY DESIGN.  The background color feature
    // has typically been used with the 'classic' font to overwrite old
    // screen contents with new data.  This ONLY works because the
    // characters are a uniform size; it's not a sensible thing to do with
    // proportionally-spaced fonts with glyphs of varying sizes (and that
    // may overlap).  To replace previously-drawn text when using a custom
    // font, use the getTextBounds() function to determine the smallest
    // rectangle encompassing a string, erase the area with fillRect(),
    // then draw new text.  This WILL infortunately 'blink' the text, but
    // is unavoidable.  Drawing 'background' pixels will NOT fix this,
    // only creates a new set of problems.  Have an idea to work around
    // this (a canvas object type for MCUs that can afford the RAM and
    // displays supporting setAddrWindow() and pushColors()), but haven't
    // implemented this yet.

    startWrite();
    for (yy = 0; yy < h; yy++) {
      for (xx = 0; xx < w; xx++) {
        if (!(bit++ & 7)) {
          bits = pgm_read_byte(&bitmap[bo++]);
        }
        if (bits & 0x80) {
          if (size_x == 1 && size_y == 1) {
            ScreenWritePixel(x + xo + xx, y + yo + yy, color);
          } else {
            ScreenFillRect(x + (xo16 + xx) * size_x, y + (yo16 + yy) * size_y,
                          size_x, size_y, color);
          }
        }
        bits <<= 1;
      }
    }
    endWrite();

  } // End classic vs custom font
}

/* [] END OF FILE */
