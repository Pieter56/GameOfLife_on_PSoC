/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "vga.h"

#define CON_PIX_SIZE 4

#define CON_BORDER 8 // Border pixels to remove

#define CON_H (((SCREEN_W - 2 * CON_BORDER) / CON_PIX_SIZE) + 1)  // extra line left
#define CON_V (((SCREEN_H - 2 * CON_BORDER - 12) / CON_PIX_SIZE) + 2)  // extra lines top and bottom

#define MID_X CON_H / 2
#define MID_Y CON_V / 2

uint8_t matrix[CON_H * CON_V];

uint16_t mp(uint8_t x, uint8_t y) {
    if (x >= CON_H) x = 0;
    if (y >= CON_V) y = 0;
    
    return x + CON_H * y;
}

/*******************************************************************************
* Function Name: ConwayInit
********************************************************************************
*
* Summary: Clears the screen and initialises some cells to start with.
*
* Parameters: none
*
* Return: none
*
*******************************************************************************/
void ConwayInit() {
    // Clear matrix
    memset(matrix, 0, sizeof(matrix));
    // Clear Screen
    ScreenFillRect(CON_BORDER, CON_BORDER + 12, SCREEN_W - 2 * CON_BORDER, SCREEN_H - 2 * CON_BORDER - 12, 0);
    /*
    // Oscillator
    matrix[mp(20,10)] = 0x80;
    matrix[mp(20,11)] = 0x80;
    matrix[mp(20,12)] = 0x80;

    // Static block
    matrix[mp(30,20)] = 0x80;
    matrix[mp(31,20)] = 0x80;
    matrix[mp(30,21)] = 0x80;
    matrix[mp(31,21)] = 0x80;
    
    // Ship
    matrix[mp(11,5)] = 0x80;
    matrix[mp(12,6)] = 0x80;
    matrix[mp(10,7)] = 0x80;
    matrix[mp(11,7)] = 0x80;
    matrix[mp(12,7)] = 0x80;
    
    */
    
    // R-pentomino
    matrix[mp(MID_X - 6, MID_Y - 2)] = 0xC0;
    matrix[mp(MID_X - 5, MID_Y - 2)] = 0xC0;
    matrix[mp(MID_X - 5, MID_Y - 3)] = 0xC0;
    matrix[mp(MID_X - 5, MID_Y - 1)] = 0xC0;
    matrix[mp(MID_X - 4, MID_Y - 3)] = 0xC0;

}

/*******************************************************************************
* Function Name: ConwayCounts
********************************************************************************
*
* Summary: Loops through the cells. If a cell is alive, increase the count of
*          all the neighbor cells. This is faster than counting the life
*          neighbors.
*
* Parameters: none
*
* Return: total of life cells.
*
*******************************************************************************/
uint16_t ConwayCounts() {
    uint16_t cell_count = 0;
    
    for (uint16_t x = 1; x < CON_H; x++)
        for (uint16_t y = 1; y < CON_V - 1; y++) {
            uint16_t k = mp(x,y);
            if (matrix[k] & 0x80) {
                cell_count++;
                matrix[k + 1] += 1;
                matrix[k - 1] += 1;
                matrix[k + CON_H] += 1;
                matrix[k - CON_H] += 1;
                matrix[k + CON_H + 1] += 1;
                matrix[k - CON_H + 1] += 1;
                matrix[k + CON_H - 1] += 1;
                matrix[k - CON_H - 1] += 1;                
            }
        }
    return cell_count;
}

/*******************************************************************************
* Function Name: ConwayNext
********************************************************************************
*
* Summary: This function is called after ConwayCounts. Each cell (byte) countains
*          it's status (most significant bit) and a count of the life neighbors.
*          (bits 3-0). The status is updated according to the Conway algorithm.
*          The count is cleared and an additional bit (bit 6) is set when the
*          cell status changes. This bit will be used to reduce the redrawing of
*          the cells on the screen.
*
* Parameters: none
*
* Return: none
*
*******************************************************************************/
void ConwayNext() {
    uint8_t val;
     
    for (uint16_t x = 1; x < CON_H; x++)
        for (uint16_t y = 1; y < CON_V - 1; y++) {
            uint16_t k = mp(x,y);
            val = matrix[k] & 0xf;
        
            if (matrix[k] & 0x80) { // Life cell
                if (val == 2 || val == 3) matrix[k] = 0x80;
                else {
                    matrix[k] = 0x40; // Mark as changed
                }
            }
            else // Dead cell
                if (val == 3) matrix[k] = 0xc0;
                else matrix[k] = 0;
    }
    
    // Erase dummy matrix elements
    for (uint16_t k = 0; k < CON_H * CON_V; k+=CON_H) matrix[k] = 0;
}

/*******************************************************************************
* Function Name: ConwayDraw
********************************************************************************
*
* Summary: This function is called after ConwayNext. It will update the screen.
*          If bit 6 is set, the cell status has changed and the cell color must
*          be changed. Bit 6 will also be reset.
*
* Parameters: none
*
* Return: none
*
*******************************************************************************/
void ConwayDraw() {
    uint8_t  val;
    
    for (uint16_t x = 1; x < CON_H; x++)
        for (uint16_t y = 1; y < CON_V - 1; y++) {
            val = matrix[mp(x,y)];
            if (val & 0x40) {
                ScreenFillRect(CON_BORDER + CON_PIX_SIZE * x, CON_BORDER + CON_PIX_SIZE * y + 10,
                           CON_PIX_SIZE, CON_PIX_SIZE, (val & 0x80) ? 1 : 0);
                matrix[mp(x,y)] &= 0xbf; // Turn off changed bit
            }
        }
}

/* [] END OF FILE */
